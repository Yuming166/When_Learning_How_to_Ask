"""Locked new-menu confirmation and declared sensitivity checks for the selected task."""
import hashlib,json,math,random
import numpy as np
import ranking_search as s
from richer_preferences import Belief,dump

OUT=s.OUT
SEEDS=[20261105231,20261105232,20261105233]
POOLS=[
    ('women_kurtas','Women','Kurtas',['test_reserved']),
    ('men_kurtas','Men','Kurtas',['validation_reserved','test_reserved']),
    ('women_dresses','Women','Dresses',['validation_reserved','test_reserved'])]

class NoisyBelief(Belief):
    def __init__(self,p,error):
        super().__init__(len(p),p)
        self.error=error
        self.observed_p=error+(1-2*error)*p
        for n,codes in enumerate(self.codes):
            digits=(codes[:,None]//self.base)%3
            self.prob[n]=np.prod(np.where(digits==0,1,np.where(digits==1,1-self.observed_p,self.observed_p)),1)

    def marginals(self,values):
        a=values.reshape((2,)*self.d+(-1,)).astype(float)
        for j in range(self.d):
            zero=np.take(a,0,axis=j);one=np.take(a,1,axis=j)
            p=self.p[j];e=self.error;y=self.observed_p[j]
            a=np.stack(((1-p)*zero+p*one,
                        ((1-p)*(1-e)*zero+p*e*one)/(1-y),
                        ((1-p)*e*zero+p*(1-e)*one)/y),axis=j)
        a=a.reshape(3**self.d,-1)
        return [a[c] for c in self.codes]

    def expect(self,values,n):
        return (1-self.observed_p)*values[self.children[n][:,:,0]]+self.observed_p*values[self.children[n][:,:,1]]

def freeze():
    locked=json.loads((OUT/'排序确认锁定.json').read_text('utf8'));base=locked['configuration']
    rows=s.source_rows()
    pools={};labels={}
    for key,gender,category,splits in POOLS:
        category_rows=[r for r in rows if (r['gender'],r['category'])==(gender,category)]
        labels[key]=s.labels_for([r for r in category_rows if r['split']=='development'])
        pools[key]=[r for r in category_rows if r['split'] in splits]
    cases=[]
    def add(name,c,pool,seeds,count,error=0):
        sample=[];seen=set()
        maximum=math.comb(len(pools[pool]),c['menu_size'])
        for seed in seeds:
            records=s.menus(pools[pool],seed,c['menu_size'],min(count,maximum))
            for ids in records:
                if ids not in seen:sample.append(dict(seed=seed,items=ids));seen.add(ids)
        cases.append(dict(name=name,config=c,category=pool,labels=labels[pool],error=error,menus=sample))
    for pool in pools:
        add('primary' if pool=='women_kurtas' else 'transfer_'+pool,base,pool,SEEDS,192)
    for step in [-.025,.025]:
        c=dict(base,threshold=round(base['threshold']+step,3))
        add(f'threshold_{c["threshold"]}',c,'women_kurtas',SEEDS[:2],64)
    for strength in [-.25,.25]:
        c=dict(base,weights=[v+strength if v>1 else v for v in base['weights']])
        add(f'importance_{strength:+}',c,'women_kurtas',SEEDS[:2],64)
    for shift in [-.05,.05]:
        c=dict(base,prior=np.clip(np.array(base['prior'])+shift,.05,.95).tolist())
        add(f'prior_{shift:+}',c,'women_kurtas',SEEDS[:2],64)
    for error in [.025,.05,.1]:
        add(f'response_error_{error}',base,'women_kurtas',SEEDS[:2],64,error)
    dev=[r for r in rows if (r['gender'],r['category'],r['split'])==('Women','Kurtas','development')]
    train=s.menus(dev,20261105221,base['menu_size'],192)
    protocol=dict(lock_sha=hashlib.sha256((OUT/'排序确认锁定.json').read_bytes()).hexdigest(),
        configuration=base,cases=cases,training_menus=train,train_labels=locked['labels'],
        criteria='Primary one-step DV > Decision-set IG > Profile IG > Fixed; all three seed means have this order, and each pooled adjacent gain has an approximate simultaneous 95% paired menu interval wholly above zero. At least 2 pp DV1-DSIG mean is the clarity target.',
        statistics='All 512 latent preference profiles integrated exactly under the declared synthetic prior. Bootstrap resamples menus within seed; 98.333% marginal percentile intervals adjust three comparisons via Bonferroni. The catalogue and population model stay fixed.',
        source_scope='Primary uses new menus from an earlier-used 24-product women-kurtas test pool. Category transfer uses previously untested men-kurtas and women-dresses validation/test products combined.',
        noise='Optional known binary symmetric error, independent by question. Every attribute is queried at most once for all methods. This is generated response noise, not measured model errors.',
        transfer_scope='Same normalized utility weights and probabilities. Binary preferred-label meanings and budget cutoffs come only from each category development catalogue.',
        candidate_selection='Only the development-locked selected configuration enters primary confirmation. All perturbations and secondary categories are reported.')
    path=OUT/'排序确认设计.json'
    if path.exists():assert json.loads(path.read_text('utf8'))==json.loads(json.dumps(protocol))
    else:dump(path,protocol)
    return rows,protocol

def intervals(records):
    a=np.array([r['rates'][:4] for r in records])*100
    difference=np.column_stack((a[:,3]-a[:,2],a[:,2]-a[:,1],a[:,1]-a[:,0]))
    seeds=np.array([r['seed'] for r in records]);groups=[np.flatnonzero(seeds==x) for x in np.unique(seeds)]
    rng=np.random.default_rng(20261105234);draws=[]
    for _ in range(50):
        ix=np.hstack([rng.choice(g,size=(100,len(g)),replace=True) for g in groups])
        draws.extend(difference[ix].mean(1))
    return np.percentile(draws,[100*.05/6,100*(1-.05/6)],axis=0).T.tolist()

def summarize(records,census=False):
    scores=100*np.mean([r['rates'] for r in records],0)
    gap=np.array([scores[3]-scores[2],scores[2]-scores[1],scores[1]-scores[0]])
    return dict(rates=scores.tolist(),adjacent_gaps=gap.tolist(),intervals=None if census else intervals(records),
                interval_scope='Exact finite catalogue census; no menu-sampling interval.' if census else 'Conditional paired-menu bootstrap with three-comparison correction.',
                no_buy=100*np.mean([r['no_buy'] for r in records]),
                no_question=100*np.mean([r['no_question'] for r in records]),
                multi_acceptable=100*np.mean([r['multi_acceptable'] for r in records]))

def run():
    rows,plan=freeze();byid={r['product_id']:r for r in rows};c=plan['configuration'];trained=Belief(9,np.array(c['prior']))
    fixed=[]
    for ids in plan['training_menus']:
        a,b=s.components([byid[i] for i in ids],plan['train_labels'],trained)
        metrics=s.evaluate(trained,s.signatures(a,b,c),True)
        fixed.append(metrics['fixed_sets'])
    score=np.mean(fixed,0);selected=int(np.flatnonzero(score>=score.max()-1e-12)[0]);actions=trained.fixed_sets[selected]
    training=dict(fields=[s.FIELDS[j] for j in actions],index=selected,development_accuracy=100*score[selected])
    dump(OUT/'确认固定顺序训练.json',training)
    results=[];path=OUT/'排序确认结果.json'
    if path.exists():results=json.loads(path.read_text('utf8'))['results']
    counts={key:sum((r['gender'],r['category'])==(gender,category) and r['split'] in splits for r in rows)
            for key,gender,category,splits in POOLS}
    for result in results:
        case=next(c for c in plan['cases'] if c['name']==result['name'])
        population=math.comb(counts[case['category']],case['config']['menu_size'])
        census=len(result['menus'])==population
        if census:
            result['summary']=summarize(result['menus'],True)
            result['seeds']={str(seed):summarize([r for r in result['menus'] if r['seed']==seed],True)
                             for seed in sorted({r['seed'] for r in result['menus']})}
            result['census']=True
    done={r['name'] for r in results}
    for case in plan['cases']:
        if case['name'] in done:continue
        c=case['config'];model=NoisyBelief(np.array(c['prior']),case['error']) if case['error'] else Belief(9,np.array(c['prior']))
        records=[]
        for menu in case['menus']:
            parts=s.components([byid[i] for i in menu['items']],case['labels'],model)
            metrics=s.evaluate(model,s.signatures(*parts,c),not case['error'])
            if not case['error']:
                metrics['rates'] += [max(metrics['fixed_sets']),metrics['fixed_sets'][selected]]
            records.append(dict(**menu,**metrics))
        census=len(records)==math.comb(counts[case['category']],c['menu_size'])
        summary=summarize(records,census)
        byseed={str(seed):summarize([r for r in records if r['seed']==seed],census) for seed in sorted({r['seed'] for r in records})}
        positive=(min(summary['adjacent_gaps'])>0) if census else all(v[0]>0 for v in summary['intervals'])
        success=positive and all(min(v['adjacent_gaps'])>0 for v in byseed.values())
        results.append(dict(name=case['name'],summary=summary,seeds=byseed,census=census,order_confirmed=bool(success),menus=records))
        dump(path,dict(design_sha=hashlib.sha256((OUT/'排序确认设计.json').read_bytes()).hexdigest(),
            code_sha=hashlib.sha256(__import__('pathlib').Path(__file__).read_bytes()).hexdigest(),
            methods=s.METHODS+['MenuFixed','TrainedFixed'],trained=training,results=results))
        print(case['name'],'rates',np.round(summary['rates'],2),'gaps',np.round(summary['adjacent_gaps'],2),'intervals',summary['intervals'],'pass',success,flush=True)
    dump(path,dict(design_sha=hashlib.sha256((OUT/'排序确认设计.json').read_bytes()).hexdigest(),
        code_sha=hashlib.sha256(__import__('pathlib').Path(__file__).read_bytes()).hexdigest(),
        methods=s.METHODS+['MenuFixed','TrainedFixed'],trained=training,results=results,
        correction='Women/Dresses has all 17 possible 16-item menus from 17 products. Its mean is a census, so the initially computed resampling interval has been withdrawn. Accuracy and ordering were unchanged.'))

if __name__=='__main__':run()
