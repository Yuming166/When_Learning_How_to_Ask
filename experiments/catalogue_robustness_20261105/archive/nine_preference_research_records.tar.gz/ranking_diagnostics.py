"""Post-confirmation diagnostics kept separate from the locked primary test."""
import hashlib,json
import numpy as np
import ranking_search as s
import ranking_confirmation as confirm
from richer_preferences import Belief,dump

OUT=s.OUT

def run():
    plan=json.loads((OUT/'排序确认设计.json').read_text('utf8'))
    source=json.loads((OUT/'排序确认结果.json').read_text('utf8'))
    primary=next(c for c in plan['cases'] if c['name']=='primary')
    raw={r['product_id']:r for r in s.source_rows()}
    base=primary['config'];labels=primary['labels'];menus=primary['menus']
    extra=[dict(name='six_preferences',config=dict(base,d=6,weights=base['weights'][:5])),
           *[dict(name=f'threshold_{t}',config=dict(base,threshold=t)) for t in [.5,.6]]]
    design=dict(stage='Added after primary results as explicitly labelled diagnostics. No primary specification or ranking is changed.',
                cases=extra,primary_design_sha=hashlib.sha256((OUT/'排序确认设计.json').read_bytes()).hexdigest(),
                purpose='Check actual changes to acceptable sets, measure six-versus-nine difficulty, and probe thresholds outside the discrete plateau.',
                same_menus_as_primary=True)
    path=OUT/'排序附加诊断设计.json'
    if path.exists():assert json.loads(path.read_text('utf8'))==design
    else:dump(path,design)
    baseline=Belief(9,np.array(base['prior']))
    base_components={tuple(m['items']):s.components([raw[x] for x in m['items']],labels,baseline) for m in menus}
    original={key:s.signatures(*value,base) for key,value in base_components.items()}
    unchanged={}
    for c in plan['cases']:
        if c['category']!='women_kurtas' or c['error']:continue
        changed=0;total=0
        for m in c['menus']:
            key=tuple(m['items'])
            candidate=s.signatures(*base_components[key],c['config'])
            changed+=int(np.any(candidate!=original[key],axis=1).sum());total+=len(candidate)
        unchanged[c['name']]=dict(changed_profiles_menus=changed,total_profiles_menus=total)
    output=[]
    for case in extra:
        c=case['config'];model=Belief(c['d'],np.array(c['prior'][:c['d']]))
        records=[];changed=0
        for m in menus:
            parts=s.components([raw[x] for x in m['items']],labels,model)
            accept=s.signatures(*parts,c)
            result=s.evaluate(model,accept,True)
            result['rates']+=[max(result['fixed_sets'])]
            if c['d']==9:changed+=int(np.any(accept!=original[tuple(m['items'])],axis=1).sum())
            records.append(dict(**m,**result))
        output.append(dict(name=case['name'],summary=confirm.summarize(records),changed_profiles_menus=changed if c['d']==9 else None,menus=records))
        print(case['name'],np.round(output[-1]['summary']['rates'],2),np.round(output[-1]['summary']['adjacent_gaps'],2),flush=True)
    primary_records=next(c for c in source['results'] if c['name']=='primary')['menus']
    purchase=np.zeros((5,2));mass_denominator=np.zeros(2)
    for r in primary_records:
        accept=original[tuple(r['items'])];mass=np.array(r['mass']);hit=np.array(r['hit_by_profile'])
        for j,mask in enumerate([~accept[:,-1],accept[:,-1]]):
            mass_denominator[j]+=mass[mask].sum();purchase[:,j]+=hit[:,mask]@mass[mask]
    dump(OUT/'排序附加诊断结果.json',dict(primary_acceptance_changes=unchanged,additional_cases=output,
         primary_conditional_accuracy=(100*purchase/mass_denominator).tolist(),
         primary_condition_share=(100*mass_denominator/mass_denominator.sum()).tolist(),
         source_sha=hashlib.sha256(__import__('pathlib').Path(__file__).read_bytes()).hexdigest()))
    print('changed',unchanged,flush=True)
    print('conditional',100*purchase/mass_denominator,flush=True)

if __name__=='__main__':run()
