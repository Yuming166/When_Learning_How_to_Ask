"""Post-confirmation audit. No language-model calls; retain every declared setting."""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
import hashlib, json, itertools, time, math
import numpy as np

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
import ranking_search as s
from richer_preferences import Belief

METHODS=['Fixed','ProfileIG','SetIG','GreedyDecision','OptimalFour','PurchaseExistenceIG','TwoStep','MenuBestFixed','TrainedFixed','RandomFour']

def dump(name,obj):
    (HERE/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')

def entropy(p):
    return -(p*np.log(np.maximum(p,1e-300))).sum(axis=1)

def calculate(model,accept,detail=False):
    """Independent policy composition on the original exact posterior operator."""
    post=model.marginals(accept)
    val=[p.max(axis=1) for p in post]
    sig=accept@(1<<np.arange(accept.shape[1]))
    ent=[entropy(p) for p in model.marginals(sig[:,None]==np.unique(sig))]
    exist=model.marginals(np.column_stack((accept[:,-1],~accept[:,-1])))
    exent=[entropy(p) for p in exist]
    h=-(model.p*np.log(model.p)+(1-model.p)*np.log(1-model.p))
    policies=[None]*4
    best=val[4]
    for n in reversed(range(4)):
        future=model.expect(best,n)
        if n<3:
            once=model.expect(val[n+2],n+1)
            after=np.max(np.where(model.unasked[n+1],once,-np.inf),axis=1)
            twice=model.expect(after,n)
        else:
            twice=model.expect(val[n+1],n)
        policies[n]=np.array([
            np.full(len(model.codes[n]),n),
            model.choose(np.broadcast_to(h,(len(model.codes[n]),model.d)),n),
            model.choose(-model.expect(ent[n+1],n),n),
            model.choose(model.expect(val[n+1],n),n),
            model.choose(future,n),
            model.choose(-model.expect(exent[n+1],n),n),
            model.choose(twice,n)])
        best=future[np.arange(len(future)),policies[n][4]]
    scores=np.broadcast_to(val[4],(7,len(val[4]))).copy()
    for n in reversed(range(4)):
        scores=np.array([model.expect(v,n)[np.arange(len(model.codes[n])),policies[n][m]] for m,v in enumerate(scores)])
    fixed=(val[4]*model.prob[4]).reshape(len(model.fixed_sets),16).sum(1)
    assert best[0]>=max(scores[:,0].max(),fixed.max())-1e-10
    out={'rates':scores[:,0].tolist(),'fixed':fixed.tolist(),'initial':float(val[0][0])}
    if detail:
        mass=np.prod(np.where(model.bits,model.p,1-model.p),axis=1)
        states=np.zeros((7,len(model.bits)),int)
        zero=np.zeros(4);queries=np.zeros((4,model.d))
        for n in range(4):
            q=policies[n][np.arange(7)[:,None],states]
            one=model.expect(val[n+1],n)
            gains=one[np.arange(len(one)),policies[n][3]]-val[n]
            zero[n]=mass[gains[states[3]]<=1e-12].sum()
            queries[n]=np.bincount(q[3],weights=mass,minlength=model.d)
            answer=model.bits[np.arange(len(model.bits))[None,:],q]
            states=model.children[n][states,q,answer]
        choice=post[4].argmax(axis=1)[states]
        hit=accept[np.arange(len(accept))[None,:],choice]
        assert np.allclose(hit@mass,scores[:,0],atol=1e-10)
        nobuy=accept[:,-1]
        out.update(mass=mass,hit=hit,choice=choice,zero=zero,queries=queries,
                   purchase=nobuy==False,
                   no_buy=float(mass[nobuy].sum()),
                   acceptable_count=(np.bincount(accept[:,:-1].sum(1),weights=mass,minlength=accept.shape[1])).tolist())
    return out

def brute_rates(model,accept):
    """Direct enumeration of posterior subsets; independent of ternary arrays."""
    bits=model.bits
    prior=np.prod(np.where(bits,model.p,1-model.p),axis=1)
    sig=accept@(1<<np.arange(accept.shape[1]))
    _,groups=np.unique(sig,return_inverse=True)
    def H(w):
        w=w[w>0]
        return -float(w@np.log(w))
    def recurse(mask,used,method):
        prob=prior[mask].sum()
        weights=prior[mask]/prob
        if len(used)==4:
            return prob*float((weights@accept[mask]).max())
        scores=np.full(model.d,-np.inf)
        for j in range(model.d):
            if j in used: continue
            score=0.
            for y in (0,1):
                child=mask & (bits[:,j]==y)
                cp=prior[child].sum()/prob
                cw=prior[child]/prior[child].sum()
                if method==2: v=-H(np.bincount(groups[child],weights=cw))
                elif method==1: v=-H(cw)
                else: v=float((cw@accept[child]).max())
                score+=cp*v
            scores[j]=score
        q=len(used) if method==0 else int(np.flatnonzero(scores>=scores.max()-1e-12)[0])
        return sum(recurse(mask & (bits[:,q]==y),used+(q,),method) for y in (0,1))
    return [recurse(np.ones(len(bits),bool),(),m) for m in range(4)]

def first_primary():
    text=(s.OUT/'排序确认结果.json').read_text(encoding='utf-8')
    pos=text.index('[',text.index('"results"'))+1
    while text[pos].isspace():pos+=1
    result=json.JSONDecoder().raw_decode(text,pos)[0]
    assert result['name']=='primary'
    return result

def primary_audit(rows,lock,plan):
    raw={r['product_id']:r for r in rows}
    case=next(c for c in plan['cases'] if c['name']=='primary')
    c=case['config'];labels=case['labels'];model=Belief(9,np.array(c['prior']))
    records=first_primary()['menus']
    totals=np.zeros((7,2));den=np.zeros(2);counts=np.zeros(17)
    initial=0.;optimal=0.;original=np.zeros(5)
    for rec in records:
        accept=s.signatures(*s.components([raw[x] for x in rec['items']],labels,model),c)
        mass=np.array(rec['mass']);hit=np.array(rec['hit_by_profile'])
        for k,mask in enumerate([~accept[:,-1],accept[:,-1]]):
            den[k]+=mass[mask].sum()
            totals[:5,k]+=hit[:,mask]@mass[mask]
        counts+=np.bincount(accept[:,:-1].sum(1),weights=mass,minlength=17)
        initial+=rec['no_question'];optimal+=rec['rates'][4];original+=rec['rates'][:5]
    # Fixed deterministic subsample, chosen before calculating extra methods.
    chosen=[records[i] for i in range(0,len(records),6)]
    extra=[];zero=[];qfreq=[];brute=[]
    for i,rec in enumerate(chosen):
        accept=s.signatures(*s.components([raw[x] for x in rec['items']],labels,model),c)
        z=calculate(model,accept,True)
        assert np.allclose(z['rates'][:5],rec['rates'][:5],atol=1e-10)
        if i<8:
            direct=brute_rates(model,accept)
            assert np.allclose(direct,z['rates'][:4],atol=1e-10)
            brute.append(float(np.max(np.abs(np.array(direct)-z['rates'][:4]))))
        extra.append(z['rates']);zero.append(z['zero']);qfreq.append(z['queries'])
    conditional=100*totals[:5]/den
    share=den/den.sum()
    buygap=conditional[3,0]-conditional[2,0]
    nogap=conditional[3,1]-conditional[2,1]
    decomposition={'purchase_share':float(share[0]),'purchase_gap_pp':float(buygap),
       'no_purchase_gap_pp':float(nogap),'purchase_contribution_pp':float(share[0]*buygap),
       'no_purchase_contribution_pp':float(share[1]*nogap)}
    summary={'n_menus':len(records),'no_question_accuracy':100*initial/len(records),
       'original_methods_accuracy':(100*original/len(records)).tolist(),
       'conditional_accuracy_purchase_then_no_purchase':conditional.tolist(),
       'decomposition':decomposition,
       'acceptable_count_distribution':(counts/len(records)).tolist(),
       'extra_methods_n':len(chosen),'extra_methods_accuracy':(100*np.mean(extra,0)).tolist(),
       'one_step_zero_gain_rate_by_question':np.mean(zero,0).tolist(),
       'one_step_question_frequency':np.mean(qfreq,0).tolist(),
       'direct_enumeration_max_abs_error':max(brute),
       'reweighted_no_purchase_share_gaps_pp':{str(x):float((1-x)*buygap+x*nogap) for x in [0,.1,.2,.5]}}
    # Reordering ties changes no posterior, acceptance rule or question budget.
    tie=[];rng=np.random.default_rng(20261105515)
    for k in range(12):
        order=rng.permutation(9)
        class TieBelief(Belief):
            def choose(self,scores,n):
                scores=np.where(self.unasked[n],scores,-np.inf)
                winner=(scores>=scores.max(1,keepdims=True)-1e-12)[:,order].argmax(1)
                return order[winner]
        b=TieBelief(9,np.array(c['prior']));rates=[]
        for rec in chosen[:32]:
            accept=s.signatures(*s.components([raw[x] for x in rec['items']],labels,b),c)
            rates.append(calculate(b,accept)['rates'])
        avg=100*np.mean(rates,0)
        tie.append({'order':order.tolist(),'rates':avg.tolist(),'greedy_minus_set_pp':float(avg[3]-avg[2])})
    summary['tie_sensitivity_32_menus']=tie
    dump('primary_audit.json',summary)
    print('PRIMARY',json.dumps({k:v for k,v in summary.items() if k not in ['one_step_question_frequency','tie_sensitivity_32_menus']},ensure_ascii=False),flush=True)
    return summary

def run():
    locked=json.loads((s.OUT/'排序确认锁定.json').read_text('utf-8'))
    oldplan=json.loads((s.OUT/'排序确认设计.json').read_text('utf-8'))
    rows=s.source_rows();base=locked['configuration']
    dev=[r for r in rows if (r['gender'],r['category'],r['split'])==('Women','Kurtas','development')]
    test=[r for r in rows if (r['gender'],r['category'],r['split'])==('Women','Kurtas','validation_reserved')]
    raw={r['product_id']:r for r in rows};labels=locked['labels']
    weights={'context':base['weights'],'equal':[1]*8,'style':[2,2,2,1,1,1,1,1]}
    priors={'locked':base['prior'],'uniform':[.5]*9,'reversed':(1-np.array(base['prior'])).tolist()}
    configs=[]
    for p,w,answer,threshold in itertools.product(priors,weights,['acceptable','best'],[.45,.55,.65]):
        configs.append(dict(base,id=f'{p}-{w}-{answer}-{threshold}',prior=priors[p],weights=weights[w],
                            answer=answer,threshold=threshold))
    train=s.menus(dev,20261105511,16,32);menus=s.menus(test,20261105512,16,64)
    protocol={'status':'Post-confirmation diagnostic; all 54 declared cases retained; no best-case selection.',
       'frozen_before_new_results':True,'source_config_sha':hashlib.sha256((s.OUT/'排序确认锁定.json').read_bytes()).hexdigest(),
       'code_sha':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'methods':METHODS,
       'configs':configs,'training_menus':train,'evaluation_menus':menus,'labels':labels,
       'scope':'Fresh combinations from an already-available validation product pool, synthetic independent preferences and exact answers. Same menus across all cases.',
       'fixed_training':'Select the best four-field subset on 32 development menus for each configuration, then evaluate without refitting on 64 validation menus.',
       'new_baselines':'Binary purchase-existence information gain; two-step receding-horizon decision rule. All use the same terminal decision and budget.',
       'primary_diagnostics':'All 576 original menus for decomposition. Every sixth menu (96) for additional methods and zero-gain statistics. First eight of these for direct independent posterior enumeration; first 32 for twelve tie orders.'}
    if (HERE/'protocol.json').exists():
        assert json.loads((HERE/'protocol.json').read_text('utf-8'))==json.loads(json.dumps(protocol))
    else:dump('protocol.json',protocol)
    primary=primary_audit(rows,locked,oldplan)
    path=HERE/'all_settings.jsonl'
    existing=[json.loads(x) for x in path.read_text('utf-8').splitlines()] if path.exists() else []
    done={x['id'] for x in existing}
    start=time.monotonic()
    with path.open('a',encoding='utf-8') as stream:
        for index,c in enumerate(configs):
            if c['id'] in done:continue
            model=Belief(9,np.array(c['prior']))
            training=[]
            for ids in train:
                accept=s.signatures(*s.components([raw[i] for i in ids],labels,model),c)
                training.append(calculate(model,accept)['fixed'])
            trained=int(np.argmax(np.mean(training,0)))
            records=[]
            for ids in menus:
                accept=s.signatures(*s.components([raw[i] for i in ids],labels,model),c)
                a=calculate(model,accept)
                rates=a['rates']+[max(a['fixed']),a['fixed'][trained],float(np.mean(a['fixed']))]
                mass=np.prod(np.where(model.bits,model.p,1-model.p),axis=1)
                records.append({'rates':rates,'initial':a['initial'],'no_buy':float(mass[accept[:,-1]].sum())})
            avg=100*np.mean([z['rates'] for z in records],0)
            gaps={'greedy_minus_set':float(avg[3]-avg[2]),'greedy_minus_trained':float(avg[3]-avg[8]),
                  'greedy_minus_menu_fixed':float(avg[3]-avg[7]),'greedy_minus_purchase_ig':float(avg[3]-avg[5]),
                  'two_step_minus_greedy':float(avg[6]-avg[3]),'optimal_minus_greedy':float(avg[4]-avg[3])}
            result={'id':c['id'],'rates':avg.tolist(),'gaps_pp':gaps,
                    'trained_questions':[s.FIELDS[j] for j in model.fixed_sets[trained]],
                    'no_purchase_share':float(np.mean([z['no_buy'] for z in records])),
                    'no_question_accuracy':100*float(np.mean([z['initial'] for z in records])),
                    'per_menu':records}
            stream.write(json.dumps(result,ensure_ascii=False)+'\n');stream.flush();existing.append(result)
            print(index+1,'/54',c['id'],np.round(avg,2).tolist(),{k:round(v,3) for k,v in gaps.items()},'seconds',round(time.monotonic()-start),flush=True)
    aggregates={}
    for label,group in [('all',existing),('acceptable',[x for x in existing if '-acceptable-' in x['id']]),('best',[x for x in existing if '-best-' in x['id']])]:
        aggregates[label]={k:{'wins':sum(x['gaps_pp'][k]>1e-9 for x in group),'ties':sum(abs(x['gaps_pp'][k])<=1e-9 for x in group),
                             'total':len(group),'mean_pp':float(np.mean([x['gaps_pp'][k] for x in group])),
                             'min_pp':min(x['gaps_pp'][k] for x in group),'max_pp':max(x['gaps_pp'][k] for x in group)} for k in existing[0]['gaps_pp']}
    dump('summary.json',{'methods':METHODS,'primary':primary,'sensitivity':aggregates,
                         'configuration_results':[{k:v for k,v in x.items() if k!='per_menu'} for x in existing]})
    print('COMPLETE',json.dumps(aggregates,ensure_ascii=False),flush=True)

if __name__=='__main__':run()
