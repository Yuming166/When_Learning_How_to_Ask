"""Full-primary follow-up for the two-step rule; the original method is retained."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import json,hashlib,time
import numpy as np
import audit as a

def run():
    plan=json.loads((a.s.OUT/'排序确认设计.json').read_text('utf-8'))
    case=next(x for x in plan['cases'] if x['name']=='primary')
    c=case['config'];labels=case['labels']
    design={'stage':'Post-confirmation full-primary extension after the 96-menu audit.',
      'motivation':'Test a two-step receding-horizon rule that values questions helping the next question; preserve the original one-step method.',
      'known_before_run':'The fixed 96-menu diagnostic showed an improvement. No parameters, budgets or acceptance sets are changed.',
      'all_original_primary_menus':True,'count':576,'new_method':'Two-step receding horizon, then the original terminal action rule.',
      'contrasts':['two-step minus original one-step','two-step minus set-information'],
      'intervals':'95% marginal paired menu bootstrap within original seed, conditional on the fixed catalogue and population; not simultaneous or selection-adjusted intervals.',
      'code_sha':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    a.dump('two_step_protocol.json',design)
    rows={x['product_id']:x for x in a.s.source_rows()}
    records=a.first_primary()['menus']
    model=a.Belief(9,np.array(c['prior']));out=[];start=time.monotonic()
    for i,r in enumerate(records):
        accept=a.s.signatures(*a.s.components([rows[x] for x in r['items']],labels,model),c)
        result=a.calculate(model,accept)['rates']
        assert np.allclose(result[:5],r['rates'][:5],atol=1e-10)
        out.append({'seed':r['seed'],'rates':result})
        if (i+1)%96==0:print('two-step full',i+1,'seconds',round(time.monotonic()-start),flush=True)
    values=100*np.array([x['rates'] for x in out]);seeds=np.array([x['seed'] for x in out])
    diff=values[:,6,None]-values[:,[3,2]]
    groups=[np.flatnonzero(seeds==x) for x in sorted(set(seeds))]
    rng=np.random.default_rng(20261105531);boots=[]
    for _ in range(50):
        ix=np.hstack([rng.choice(g,size=(100,len(g)),replace=True) for g in groups])
        boots.extend(diff[ix].mean(axis=1))
    ans={'methods':a.METHODS[:7],'mean_accuracy':values.mean(axis=0).tolist(),
         'contrasts':design['contrasts'],'mean_gaps_pp':diff.mean(axis=0).tolist(),
         'marginal_95_intervals':np.percentile(boots,[2.5,97.5],axis=0).T.tolist(),
         'by_seed':{str(x):values[seeds==x].mean(axis=0).tolist() for x in sorted(set(seeds))},'menus':out}
    a.dump('two_step_full_primary.json',ans)
    print('FULL TWO STEP',json.dumps({k:v for k,v in ans.items() if k!='menus'}),flush=True)

if __name__=='__main__':run()
