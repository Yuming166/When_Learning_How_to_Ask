"""Independent direct-subset check of the additional two-step policy."""
import sys
sys.dont_write_bytecode=True
from functools import lru_cache
import json
import numpy as np
import audit as a

def direct(model,accept):
    bits=model.bits
    mass=np.prod(np.where(bits,model.p,1-model.p),axis=1)
    @lru_cache(None)
    def posterior(state):
        mask=np.ones(len(bits),bool)
        for j,y in enumerate(state):
            if y!=-1:mask &= bits[:,j]==y
        prob=mass[mask].sum()
        value=float((mass[mask]@accept[mask]).max()/prob)
        return mask,float(prob),value
    @lru_cache(None)
    def next_values(state):
        _,prob,_=posterior(state)
        children=[]
        for j in range(model.d):
            if state[j]!=-1:continue
            branch=[]
            for y in (0,1):
                child=list(state);child[j]=y;child=tuple(child)
                branch.append((posterior(child)[1]/prob,child))
            children.append((j,branch))
        return children
    @lru_cache(None)
    def planned_value(state,left):
        if left==0:return posterior(state)[2]
        return max(sum(prob*planned_value(child,left-1) for prob,child in branch) for _,branch in next_values(state))
    def actual(state):
        used=sum(y!=-1 for y in state)
        if used==4:return posterior(state)[1]*posterior(state)[2]
        choices=next_values(state)
        scores=[sum(p*planned_value(child,min(2,4-used)-1) for p,child in branch) for _,branch in choices]
        chosen=int(np.flatnonzero(np.array(scores)>=max(scores)-1e-12)[0])
        return sum(actual(child) for _,child in choices[chosen][1])
    return actual((-1,)*model.d)

def run():
    p=json.loads((a.s.OUT/'排序确认设计.json').read_text('utf-8'))
    case=next(x for x in p['cases'] if x['name']=='primary')
    rows={x['product_id']:x for x in a.s.source_rows()};c=case['config']
    model=a.Belief(9,np.array(c['prior']));results=[]
    for rec in case['menus'][:4]:
        accept=a.s.signatures(*a.s.components([rows[x] for x in rec['items']],case['labels'],model),c)
        value=direct(model,accept);reference=a.calculate(model,accept)['rates'][6]
        assert abs(value-reference)<1e-10
        results.append({'direct':value,'array_algorithm':reference,'absolute_error':abs(value-reference)})
    a.dump('two_step_independent_check.json',{'checks':results,'max_absolute_error':max(x['absolute_error'] for x in results)})
    print(json.dumps(results))

if __name__=='__main__':run()
