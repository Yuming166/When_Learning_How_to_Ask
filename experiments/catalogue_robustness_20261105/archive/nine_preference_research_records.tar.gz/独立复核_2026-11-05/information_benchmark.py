"""Floating-point exchange bounds for the paper's weighted-five KL benchmark.
Rates are fitted analytically for each flip/type pattern. Bounds are numerical,
not an outward-rounded proof certificate and not empirical interaction costs.
"""
from pathlib import Path
import itertools,json
import numpy as np
from scipy.optimize import linprog
from scipy.special import xlogy

HERE=Path(__file__).resolve().parent
D=5;P=.8;Q=.6;ETA=.05
COEF=np.array([3,2,2,1,1])
ALL=[tuple(i for i,b in enumerate(bits) if b) for bits in itertools.product([0,1],repeat=D) if sum(COEF*np.where(bits,-1,1))<0]
FLIPS=[f for f in ALL if not any(set(g)<set(f) for g in ALL)]
assert {tuple(i+1 for i in f) for f in FLIPS}=={(1,2),(1,3),(2,3,4),(2,3,5),(1,4,5)}
TRUTH=np.tile([P,Q],D)
J=np.repeat(np.arange(D),2);M=np.tile([0,1],D)

def kl(a,b):
    return xlogy(a,a/b)+xlogy(1-a,(1-a)/(1-b))

def alternative(weights,flip,z,groups):
    target=np.where(np.isin(J,flip),1-TRUTH,TRUTH)
    high=M==np.array(z)[groups[J]]
    wh=weights[high].sum();wl=weights[~high].sum()
    ph=np.clip(weights[high]@target[high]/wh,.5,1-ETA) if wh>1e-15 else .5
    pl=np.clip(weights[~high]@target[~high]/wl,.5,1-ETA) if wl>1e-15 else .5
    if wh<=1e-15:ph=max(ph,pl)
    if wl<=1e-15:pl=min(pl,ph)
    if ph<pl:ph=pl=np.clip(weights@target,.5,1-ETA)
    rate=np.where(high,ph,pl)
    outcome=np.where(np.isin(J,flip),1-rate,rate)
    div=kl(TRUTH,outcome)
    return float(weights@div),div,(float(ph),float(pl))

def solve(groups,oracle=False,tol=1e-7):
    G=int(max(groups))+1
    alternatives=list(itertools.product(FLIPS,[(0,)*G] if oracle else list(itertools.product([0,1],repeat=G))))
    w=np.full(2*D,1/(2*D));cuts=[]
    for f,z in alternatives:cuts.append(alternative(w,f,z,groups)[1])
    for iteration in range(200):
        matrix=np.column_stack((-np.array(cuts),np.ones(len(cuts))))
        lp=linprog(np.r_[np.zeros(2*D),-1],A_ub=matrix,b_ub=np.zeros(len(cuts)),
                   A_eq=[np.r_[np.ones(2*D),0]],b_eq=[1],bounds=[(0,None)]*(2*D+1),
                   method='highs',options={'dual_feasibility_tolerance':1e-9,'primal_feasibility_tolerance':1e-9})
        assert lp.success,lp.message
        w=lp.x[:-1];upper=lp.x[-1]
        fits=[alternative(w,f,z,groups) for f,z in alternatives]
        lower=min(a[0] for a in fits)
        if upper-lower<=tol:
            return dict(iterations=iteration+1,information_lower=lower,information_upper=upper,
                        cost_lower=1/upper,cost_upper=1/lower,allocation=w.reshape(D,2).tolist(),
                        residual_information_gap=upper-lower)
        new=[a[1] for a in fits if a[0]<upper-tol*.5]
        cuts.extend(new)
    raise RuntimeError('Exchange did not converge')

def run():
    answer={}
    for name,groups in [('zero_premium',np.array([0,0,1,1,1])),('positive_premium',np.array([0,1,1,0,1]))]:
        learner=solve(groups);oracle=solve(groups,True)
        expected=1/float(kl(P,.5))
        assert abs(oracle['cost_upper']-expected)<1e-6
        answer[name]={'unknown_formats':learner,'known_formats':oracle,
           'relative_cost_increase_lower':learner['cost_lower']/oracle['cost_upper']-1,
           'relative_cost_increase_upper':learner['cost_upper']/oracle['cost_lower']-1}
    output={'scope':'Numerical benchmark at p=0.8,q=0.6,eta=0.05, all-positive true preferences, same weighted-five catalogue. Not a simulation or formal interval certificate.',
            'minimal_flip_sets':[[i+1 for i in f] for f in FLIPS],'results':answer}
    (HERE/'information_benchmark.json').write_text(json.dumps(output,indent=2),encoding='utf-8')
    print(json.dumps(output,indent=2))

if __name__=='__main__':run()
