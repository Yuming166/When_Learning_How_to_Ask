"""Large fresh development menus choose a configuration before any new confirmation."""
import hashlib,json
import numpy as np
import ranking_search as search
from richer_preferences import Belief,dump

OUT=search.OUT

def run():
    designs=json.loads((OUT/'第二批开发设计.json').read_text('utf8'))
    ranked=json.loads((OUT/'第二批开发排序.json').read_text('utf8'))
    lookup={c['id']:c for c in designs['configurations']}
    configs=[lookup[r['id']] for r in ranked[:8]]
    dev=[r for r in search.source_rows() if (r['gender'],r['category'],r['split'])==('Women','Kurtas','development')]
    byid={r['product_id']:r for r in dev};labels=search.labels_for(dev);seeds=[20261105211,20261105212]
    menus={str(n):[dict(seed=s,items=x) for s in seeds for x in search.menus(dev,s,n,96)] for n in sorted({c['menu_size'] for c in configs})}
    plan=dict(configurations=configs,seeds=seeds,menus=menus,labels=labels,
              purpose='Development replication on 192 fresh menus per configuration. Select the largest minimum adjacent mean gap, requiring both menu-seed means positive. Confirmation remains unopened.',
              prior_search_sha=hashlib.sha256((OUT/'第二批开发排序.json').read_bytes()).hexdigest())
    path=OUT/'开发扩大检验设计.json'
    if path.exists():assert json.loads(path.read_text('utf8'))==json.loads(json.dumps(plan))
    else:dump(path,plan)
    completed=[];file=OUT/'开发扩大检验结果.json'
    if file.exists():completed=json.loads(file.read_text('utf8'))
    done={r['id'] for r in completed}
    for c in configs:
        if c['id'] in done:continue
        model=Belief(9,np.array(c['prior']));records=[]
        for m in menus[str(c['menu_size'])]:
            parts=search.components([byid[x] for x in m['items']],labels,model)
            metrics=search.evaluate(model,search.signatures(*parts,c))
            records.append(dict(**m,**metrics))
        def summarize(sub):
            avg=np.mean([r['rates'] for r in sub],0)*100
            gaps=[avg[3]-avg[2],avg[2]-avg[1],avg[1]-avg[0]]
            return dict(rates=avg.tolist(),gaps=gaps,minimum_gap=min(gaps))
        row=dict(id=c['id'],pooled=summarize(records),by_seed={str(s):summarize([r for r in records if r['seed']==s]) for s in seeds},menus=records)
        completed.append(row);dump(file,completed)
        print(c['id'],np.round(row['pooled']['rates'],2),'min',round(row['pooled']['minimum_gap'],3),flush=True)
    eligible=[r for r in completed if all(s['minimum_gap']>0 for s in r['by_seed'].values())]
    if not eligible:
        print('No configuration passes development replication',flush=True);return
    selected=max(eligible,key=lambda r:r['pooled']['minimum_gap'])
    c=lookup[selected['id']]
    lock=dict(configuration=c,development=selected['pooled'],rule=plan['purpose'],
              fields=search.FIELDS,labels=labels,models=search.METHODS,budget=4,
              search_cells=160+576,large_development_candidates=len(configs),
              sources={f:hashlib.sha256((OUT/f).read_bytes()).hexdigest() for f in ['开发探索设计.json','开发探索排序.json','第二批开发设计.json','第二批开发排序.json','开发扩大检验设计.json','开发扩大检验结果.json']},
              scope='A development-selected synthetic acceptable-item task on real catalogues. Primary algorithm is one-step DV1.',
              confirm='Freeze before new menu outcomes. Require all three adjacent gaps positive with paired menu intervals excluding zero. Report both seeds, perturbed settings, secondary categories, and failures.')
    lockfile=OUT/'排序确认锁定.json'
    if lockfile.exists():assert json.loads(lockfile.read_text('utf8'))==lock
    else:dump(lockfile,lock)
    print('LOCKED',c['id'],flush=True)

if __name__=='__main__':run()
