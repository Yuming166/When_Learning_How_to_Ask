"""Second development search, including more menus, weight strengths and acceptable thresholds."""
import hashlib,json,random,time
import numpy as np
import ranking_search as search
from richer_preferences import Belief,dump

OUT=search.OUT

def design():
    distributions={
        'assigned':search.P0.tolist(),
        'reversed':(1-search.P0).tolist(),
        'uncertain_context':[.15,.2,.85,.25,.7,.5,.5,.5,.5],
        'uncertain_style':[.5,.5,.5,.35,.2,.6,.15,.2,.8],
    }
    tasks=[]
    for pn,p in distributions.items():
        for axis,indices in [('care_material',[3,4]),('context_fit',[5,6,7])]:
            for strength in [2,3,4]:
                weights=[strength if j in indices else 1 for j in range(8)]
                for size in [4,8,12,16]:
                    for cut in [.4,.45,.5,.55,.6,.65]:
                        key=f'{pn}-{axis}{strength}-n{size}-t{cut}'
                        tasks.append(dict(id=key,d=9,menu_size=size,answer='acceptable',prior=p,prior_name=pn,
                            weights=weights,weight_name=f'{axis}{strength}',threshold=cut,price_penalty=.05,hard=[]))
    rows=search.source_rows()
    dev=[r for r in rows if (r['gender'],r['category'],r['split'])==('Women','Kurtas','development')]
    selected={str(n):search.menus(dev,20261105202+n,n,24) for n in [4,8,12,16]}
    protocol=dict(stage=2,budget=4,scope='Development only; follows the complete retained stage-one grid. Every attempted setting is retained.',
                  target='DV1 > DecisionSetIG > ProfileIG > Fixed; maximize smallest adjacent mean gap.',
                  configurations=tasks,menus=selected,labels=search.labels_for(dev),
                  source_sha=hashlib.sha256(search.prior.SOURCE.read_bytes()).hexdigest())
    path=OUT/'第二批开发设计.json'
    if path.exists():assert json.loads(path.read_text('utf8'))==json.loads(json.dumps(protocol))
    else:dump(path,protocol)
    return dev,protocol

def run():
    dev,protocol=design();byid={r['product_id']:r for r in dev};models={};parts={}
    path=OUT/'第二批开发结果.jsonl'
    records=[json.loads(s) for s in path.read_text('utf8').splitlines()] if path.exists() else []
    done={r['id'] for r in records};start=time.monotonic()
    with path.open('a',encoding='utf8') as stream:
        for i,c in enumerate(protocol['configurations']):
            if c['id'] in done:continue
            prior=c['prior_name'];key=(prior,c['menu_size'])
            if prior not in models:models[prior]=Belief(9,np.array(c['prior']))
            if key not in parts:
                parts[key]=[search.components([byid[p] for p in ids],protocol['labels'],models[prior]) for ids in protocol['menus'][str(c['menu_size'])]]
            output=[search.evaluate(models[prior],search.signatures(a,b,c)) for a,b in parts[key]]
            avg=np.mean([r['rates'] for r in output],0)*100
            gaps=np.array([avg[3]-avg[2],avg[2]-avg[1],avg[1]-avg[0]])
            record=dict(id=c['id'],rates=avg.tolist(),adjacent_gaps=gaps.tolist(),minimum_gap=float(gaps.min()),
                no_question=100*np.mean([r['no_question'] for r in output]),no_buy=100*np.mean([r['no_buy'] for r in output]),
                multi_acceptable=100*np.mean([r['multi_acceptable'] for r in output]),per_menu=output)
            stream.write(json.dumps(record,ensure_ascii=False)+'\n');stream.flush();records.append(record)
            if (i+1)%96==0:
                best=max(records,key=lambda r:r['minimum_gap'])
                print(i+1,round(time.monotonic()-start),'best',best['id'],np.round(best['rates'],2),round(best['minimum_gap'],2),flush=True)
    ranked=sorted(records,key=lambda r:r['minimum_gap'],reverse=True)
    dump(OUT/'第二批开发排序.json',[{k:v for k,v in r.items() if k!='per_menu'} for r in ranked])
    print([(r['id'],np.round(r['rates'],2).tolist(),r['minimum_gap']) for r in ranked[:8]],flush=True)

if __name__=='__main__':run()
